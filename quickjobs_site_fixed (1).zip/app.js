document.addEventListener("DOMContentLoaded", () => {
  const jobs = [
    { title: "Lawn mowing", location: "Dublin", pay: "€30" },
    { title: "Fix sink", location: "Cork", pay: "€60" },
    { title: "Fence installation", location: "Galway", pay: "€120" }
  ];

  const jobsList = document.getElementById("jobs");
  if (jobsList) {
    jobs.forEach(job => {
      const li = document.createElement("li");
      li.textContent = `${job.title} - ${job.location} - ${job.pay}`;
      jobsList.appendChild(li);
    });
  }
});
